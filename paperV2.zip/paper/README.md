# Flood Rescue Paper Draft

This folder contains the preliminary LNCS-style LaTeX manuscript.

## Files

- `main.tex`: main paper draft.
- `llncs.cls`: Springer LNCS document class copied from the provided template.
- `splncs04.bst`: LNCS BibTeX style copied from the provided template.

## Compile

From this folder:

```powershell
pdflatex main.tex
pdflatex main.tex
```

The current machine did not have `pdflatex`, `xelatex`, or `python` in PATH during draft creation, so the PDF was not generated locally.

## Sections To Update After Experiments

- Final Edge AI accuracy/F1, model size, and mobile inference latency.
- Final Louvain/DBSCAN/ST-DBSCAN clustering metrics.
- Network simulation results for full payload vs compact metadata.
- Final author emails, ORCID IDs, acknowledgments, and target conference formatting rules.
