import '../send_mode.dart';

/// Một báo cáo cứu hộ + toàn bộ metric đo được (dung lượng, thời gian, mạng).
class RescueRecord {
  final String id;
  final int createdAtMs;

  // Kết quả inference on-device
  final String label;
  final double confidence;

  // Vị trí + ghi chú
  final double? lat;
  final double? lng;
  final String note;

  // Dữ liệu gửi
  final String? imagePath; // bản copy bền trong app support dir
  final SendMode mode;
  final String status; // pending | sent | sms_sent

  // === METRICS (trọng tâm NCKH) ===
  final int bytesOriginal;
  final int bytesSent;
  final int durationUploadMs; // thời gian request upload
  final int durationInferenceMs; // thời gian model chạy trên máy
  final String networkType; // wifi | mobile | none
  final int throughputKbps;
  final int attempts;

  const RescueRecord({
    required this.id,
    required this.createdAtMs,
    required this.label,
    required this.confidence,
    required this.lat,
    required this.lng,
    required this.note,
    required this.imagePath,
    required this.mode,
    required this.status,
    required this.bytesOriginal,
    required this.bytesSent,
    required this.durationUploadMs,
    required this.durationInferenceMs,
    required this.networkType,
    required this.throughputKbps,
    required this.attempts,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'createdAtMs': createdAtMs,
        'label': label,
        'confidence': confidence,
        'lat': lat,
        'lng': lng,
        'note': note,
        'imagePath': imagePath,
        'mode': mode.name,
        'status': status,
        'bytesOriginal': bytesOriginal,
        'bytesSent': bytesSent,
        'durationUploadMs': durationUploadMs,
        'durationInferenceMs': durationInferenceMs,
        'networkType': networkType,
        'throughputKbps': throughputKbps,
        'attempts': attempts,
      };

  factory RescueRecord.fromMap(Map<dynamic, dynamic> m) => RescueRecord(
        id: m['id'] as String,
        createdAtMs: m['createdAtMs'] as int,
        label: (m['label'] ?? 'unknown') as String,
        confidence: ((m['confidence'] ?? 0) as num).toDouble(),
        lat: (m['lat'] as num?)?.toDouble(),
        lng: (m['lng'] as num?)?.toDouble(),
        note: (m['note'] ?? '') as String,
        imagePath: m['imagePath'] as String?,
        mode: SendMode.values.firstWhere(
          (v) => v.name == m['mode'],
          orElse: () => SendMode.queuedOffline,
        ),
        status: (m['status'] ?? 'pending') as String,
        bytesOriginal: ((m['bytesOriginal'] ?? 0) as num).toInt(),
        bytesSent: ((m['bytesSent'] ?? 0) as num).toInt(),
        durationUploadMs: ((m['durationUploadMs'] ?? 0) as num).toInt(),
        durationInferenceMs: ((m['durationInferenceMs'] ?? 0) as num).toInt(),
        networkType: (m['networkType'] ?? 'unknown') as String,
        throughputKbps: ((m['throughputKbps'] ?? 0) as num).toInt(),
        attempts: ((m['attempts'] ?? 0) as num).toInt(),
      );

  RescueRecord copyWith({
    SendMode? mode,
    String? status,
    int? bytesSent,
    int? durationUploadMs,
    String? networkType,
    int? throughputKbps,
    int? attempts,
  }) =>
      RescueRecord(
        id: id,
        createdAtMs: createdAtMs,
        label: label,
        confidence: confidence,
        lat: lat,
        lng: lng,
        note: note,
        imagePath: imagePath,
        mode: mode ?? this.mode,
        status: status ?? this.status,
        bytesOriginal: bytesOriginal,
        bytesSent: bytesSent ?? this.bytesSent,
        durationUploadMs: durationUploadMs ?? this.durationUploadMs,
        durationInferenceMs: durationInferenceMs,
        networkType: networkType ?? this.networkType,
        throughputKbps: throughputKbps ?? this.throughputKbps,
        attempts: attempts ?? this.attempts,
      );
}
